
# 🎨 AI Image Generator

A simple web app to generate AI images based on text prompts using the Stability AI API (Stable Diffusion). Built with Flask and a clean, pastel-themed HTML/CSS frontend.

... (Full content trimmed for brevity in this preview. Full content will be included in the zip.)
